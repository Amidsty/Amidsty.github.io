## README

### 使用前须知

使用前请 `Win + R` 打开注册表编辑器，

找到 计算机\HKEY_CURRENT_USER\Console\，

右键新建 DWORD(32bit) 值，命名为 VirtualTerminalLevel，将数值改为 1。

`lib` 文件夹中的 `config.txt` 可以更改显示颜色。

### 使用须知

支持自定义单词表，先英文后中文，中间用 `::` 隔开。

$100$ 词测试词表比较抽象，都是随机找出来的词，比较困难，还有可能有错词。。

如果你不想测完，输入 `END` 即可进入结算。

结算会给出正确率和连胜记录。建议选择模式 $2$，即中译英。

## Expack

多人联机。

使用时一人先打开 `server`，随之所有人可打开 `client`。

`expack/lib/config.txt`可以更改显示颜色。

其余用法基本相同。
