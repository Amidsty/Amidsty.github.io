#ifndef __RGB_H__
#define __RGB_H__
#include <windows.h>
#include <wchar.h>
#include <cstdio>
struct col {int R,G,B;};
void RGBinit()
{
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    if (hOut == INVALID_HANDLE_VALUE) exit( GetLastError() );
    DWORD dwMode = 0;
    if (!GetConsoleMode(hOut, &dwMode)) exit( GetLastError() );
    dwMode |= 0x0004;
    if (!SetConsoleMode(hOut, dwMode)) exit( GetLastError() );
}
void RGBprint(const char *s,int fR,int fG,int fB,int bR,int bG,int bB)
{
	wprintf(L"\x1b[38;2;%d;%d;%dm\x1b[48;2;%d;%d;%dm%s",fR,fG,fB,bR,bG,bB,s);
}
void RGBprint(const char *s,col f,col b)
{
	wprintf(L"\x1b[38;2;%d;%d;%dm\x1b[48;2;%d;%d;%dm%s",f.R,f.G,f.B,b.R,b.G,b.B,s);
}
#endif
